﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class tables_generator : System.Web.UI.UserControl
    {
        int length;

        Panel create_tables_panel() 
        {
            //cria o control com CssClass que contera as tabuadas e o retorna
            Panel tables_panel = new Panel();
            tables_panel.CssClass = "tables_panel";

            return tables_panel;
        }

        void check_jump_line(int i, ref Panel tables) 
        {
            if (i % 5 == 0) // verifica se  "i" e' divisivel por 5, caso sim, cria uma quebra de linha
            {

                //cria uma quebra de linha
                Literal l = new Literal();
                l.Text = "<div/>";
                //----


                tables.Controls.Add(l); // adiciona quebra de linha
            }
        }
        
        public tables_generator(int tables_length) 
        {
            this.length = tables_length; //armazena na variavel length o numero de tabuadas a' serem geradas 
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            Panel tables_panel = create_tables_panel(); // cria o control que contera todas as tabuadas

            //Loop que adiciona tabuada por tabuada
            for (int i = 1; i <= length; i++)
            {
                tables_panel.Controls.Add(new simple_table(i)); //cria e adiciona apenas uma tabuada no "tables_panel" passando "i" como argumento para calcular sua tabuada

                check_jump_line(i, ref tables_panel); //verifica se e' o quinto elemento da linha e se sim pula para proxima 
            }

            this.Controls.Add(tables_panel); //por fim adiciona a tabuada pronta
        }
    }
}