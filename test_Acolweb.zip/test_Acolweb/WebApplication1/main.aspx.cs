﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class main : System.Web.UI.Page
    {

        bool valid_input(out int input) //Verifica se a entrada e' numerica e caso sim retorna ela
        {
            return int.TryParse(tables_number.Text, out input);
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void generate_button_Click(object sender, EventArgs e)
        {
            int input; //variavel que armazenara o numero de tabuadas a serem geradas

            if (valid_input(out input)) //valida a entrada de dados
            {
                this.form1.Controls.Add(new tables_generator(input)); // cria e adiciona o control "tables_generator" com inpunt como argumento para gerar n tabuadas
            }
            else 
            {
                tables_number.Text = "Entrada invalida!"; //mostra ao usuario uma mensagem de entrada invalida
            }
        }
    }
}