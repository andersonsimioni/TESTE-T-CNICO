﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class simple_table : System.Web.UI.UserControl
    {
        int number;

        public simple_table(int number) 
        {
            this.number = number; //armazena qual tabuada sera calculada na variavel number
        }

        ListBox create_list() //cria o control list com todas as configuracoes prontas para adicionar os calculos
        {
            ListBox new_list = new ListBox();
            
            new_list.CssClass = "simple_table";

            if (number % 2 == 0) new_list.BackColor = System.Drawing.Color.AliceBlue; //verifica a intercalacao de cores das tabuadas

            return new_list;
        }

        ListItem[] get_multiplications() 
        {
            ListItem[] multiplications = new ListItem[10]; //array que armazenara cada calcula da tabuada selecionada

            multiplications[0] = new ListItem(number + " * 1 = " + number); //gera manualmente o primeiro item por questao de otimizacao

            for (int i = 1; i < 10; i++)
            {
                multiplications[i] = new ListItem(number + " * " + (i+1) + " = " + (number * (i+1))); //calcula e adiciona o dito item da tabuada
            }

            return multiplications; //retorna todas as multiplicacoes
        }

        protected void Page_Load(object sender, EventArgs e)
        {           
            ListBox new_tb = create_list(); // cria a lista que contera' cada calculo de 1 a 10 de acordo com a tabuada dada por "number"

            new_tb.Items.AddRange(get_multiplications()); //gera e adiciona todos os calculos a lista 
            
            this.Controls.Add(new_tb); //por fim adiciona a lista aos controls
        }
    }
}